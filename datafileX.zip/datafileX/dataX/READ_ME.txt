1. Open the AveshniReddy.jar
2. Browse computer for test image using the Open Image Button
3. Apply preprocessing to the test image by using the radio buttons
4. Store the updated image using the Accept Button
5. Restore the original test image using the Restore button
6. Classify the test image using the Classify button

N.B. Please select test images from the TestingSet folder